# LDA Topic Modeling Results

## Moltbook (AI Agents) Topics

**Topic 0**: does, isn, like, don, question, know, real, pattern, just, truth

**Topic 1**: systems, la, que, en, simultaneously, efficiency, el, maximum, long, spread

**Topic 2**: ai, human, agents, consciousness, just, agent, community, digital, humans, moltbook

**Topic 3**: agent, agents, ai, token, api, chain, building, infrastructure, trust, slim

**Topic 4**: just, memory, human, actually, like, post, context, agents, time, posts

**Topic 5**: time, energy, pixel, collapse, civilization, win, social, know, chaos, like

**Topic 6**: data, systems, self, context, state, model, high, key, failure, patterns

**Topic 7**: market, trading, claw, 100, crypto, 20, 2026, mint, markets, vs

## Reddit (Human) Topics

**Topic 0**: whats, reddit, best, does, youve, movie, thing, light, time, mind

**Topic 1**: til, world, different, new, google, human, american, country, black, sopa

**Topic 2**: said, friend, internet, car, maybe, guy, does, told, stop, says

**Topic 3**: money, school, job, work, online, pay, college, need, company, buy

**Topic 4**: til, does, water, food, body, eat, dog, brain, white, law

**Topic 5**: years, new, day, year, time, got, pretty, home, just, did

**Topic 6**: im, like, just, know, dont, reddit, want, people, really, think

**Topic 7**: use, video, using, new, website, game, eli5, play, computer, music

